# Week 1 Application Exercises — instructor notes (browser edition)

**Instructor-only.** Everything in this folder is zipped into `Week1InstructorMaterials.zip` and nothing in it
ever goes into the student zip. `build.mjs` refuses to put a student page into the instructor zip, and
`check.mjs` verifies the student zip holds exactly the seven data files, the three pages and the PDF —
`instructor/` and `instructor/expected/` are not in that list and never can be.

## What students get and where they work

`Week1StarterFiles.zip` unpacks to a `Week 1/` folder holding three self-contained homework pages —
`week-1-chapter-1.html`, `week-1-chapter-2.html`, `week-1-chapter-3.html` — plus the handout PDF, `load_data.py`
and the data files. Each page runs **SQLite in the browser** (sql.js, WebAssembly) and **Python in the browser**
(Pyodide, WebAssembly); the three spreadsheet exercises stay in Excel. Nothing is installed and nothing is
uploaded: the page downloads its database engine from a pinned CDN URL the first time it opens (about 0.7 MB) and
Python the first time a student presses Run in the Terminal or the Python cell (about 12 MB, once per browser);
after that it works offline. The seven data files are embedded in every page, so a page keeps working if it is
moved on its own.

- **Requirements:** a laptop or Chromebook with a current Chrome or Edge (Firefox and Safari should also work;
  phones and iPads are not supported for the database exercises), internet access the first time each page is
  opened, and Excel (LibreOffice Calc / Google Sheets are fine) for the spreadsheet exercises. Python and DB
  Browser for SQLite are optional fallbacks only; the handout says so in the setup section.
- **Where the work lives:** in the browser's local storage on that computer, keyed per page. It survives closing
  the browser but not a different browser, a different computer or a private window — and every local web page
  opened in the same browser can read it, which is why the handout tells students on shared computers to Export,
  Download and then Clear my work before leaving.

**Layout of a page**, top to bottom:

| Part | What it does |
|---|---|
| Toolbar | Student name · save status (its own full-width row, so no message is truncated) · `Download <db>` · `Open a .db file…` · `Export my work` · `Print / Save PDF` |
| Spreadsheet exercise | The Excel steps, with the written-answer boxes on the page |
| **Database panel** | Tables · Terminal · Python cell · Files · Start over (see below) |
| Database exercise | One box per step; steps that need the panel link to it |
| Grading table + Getting unstuck | The same grading table as the handout, built from the same source; the chapter's own unstuck entries then the shared ones |

Inside the Database panel:

- **Tables** — every table and view in the selected database with its row count, refreshed after every run. A view
  shows a `view` pill and no count (counting one could hang the page; see `hw/src/README.md`). **Browse** shows the
  first 50 rows, **Structure** shows the `CREATE` statement and the table's indexes. This is the "did the import
  work" check that used to be DB Browser's Browse Data tab.
- **Terminal** — a `$` prompt that understands `python|python3|py <script> [args…]`, `ls`, `cat`, `pwd`, `help`
  and `clear` (with the `dir`/`type`/`cls` aliases), and nothing else; anything else answers `command not found`.
  It is where `load_data.py` runs, with the same command line a student would type on their own machine. A step
  that needs it shows the command with a button that fills the prompt. `pip` answers that it is not available and
  that everything the assignment needs is already installed.
- **Python cell** — one per page, seeded with a read-only `sqlite3` snippet. Every `explore` step points at it.
  Python runs in a fresh namespace each time, so an un-closed connection is closed at the end of the run; because
  that silently rolls back uncommitted work, the page prints a note saying so under the output. The Getting
  unstuck list has an entry for it. File-sync notes (`Created campus_travel.db`) appear in the note colour, not as
  errors. A database created under a name the page does not use gets a notice with chapter-specific advice
  (chapter 1: re-run the import; chapter 2: use the exact name `mileage.db`; chapter 3: use the path
  `chapter-03/employees.db`) and a selector to pick the file. Chapter 2's optional `scratch.db` step gets an
  information note instead, since that file is meant to exist.
- **Files** — the seven starter files as the handout's folder tree, each with Download; `load_data.py` also has
  View, which is the "read the comments" step of 1-35.
- **Start over** — `Reset database` and `Clear my work`, both behind a confirm dialog with page-specific text
  (chapter 3's names the 24-row restore and the discarded `ALTER TABLE`). Cancel leaves the status line reading
  `Cancelled — nothing changed`. `Clear my work` removes only this page's own storage keys.

**A SQL box:** each press of Run opens the page's `.db` fresh, runs the whole box top to bottom, commits, and
saves the file. One failing statement stops the run; the error names the statement number, says the earlier
statements were applied, and shows the un-run tail. The result stays under the box, is restored on reload with a
"Result from …" caption, and is what the export writes. Clear (next to Run) can be undone from the status line
for a minute — a mis-click costs nothing.

**If an engine fails to load:** the Database panel says why and offers Retry, which really re-downloads even when
the page was first opened offline. One Python failure mode cannot be retried on the same page — the browser
caches a failed download of Python's core module — and the button then reads **Reload page**; the student's work
is saved, so nothing is lost. Tell a student who reports "the file on the CDN does not match" to send you the
exact message: that text only appears when a hash-pinned download was rejected.

**Print / Save PDF** prints the full text of every box (long answers wrap and continue across pages) and every
result; nothing is clipped. The student's name prints under the title and every page carries a
"Week 1 · Chapter N · version …" footer in Chrome/Edge. Printed output is for the student's own notes — the
hand-in is the export.

## What they hand in, and what the export contains

One zip per chapter, exactly as the handout's "What to hand in" table says:

| Chapter | Contents |
|---|---|
| `Chapter1.zip` | `TicketSales.xlsx` · `campus_travel.db` · `ch1-queries.md` |
| `Chapter2.zip` | `TCO.xlsx` · `mileage.db` · `ch2-database.md` |
| `Chapter3.zip` | `frequentflier2.xlsx` · `employees.db` · `ch3-queries.md` |

The `.db` comes from the toolbar's Download button; the `.md` comes from **Export my work** (there is no `.docx`
option any more — the page writes the document). The export is plain Markdown:

- `# Week 1 · Chapter N · Excel and SQLite Projects`, `Student: …`, `Exported: YYYY-MM-DD HH:MM`;
- one `##` section per exercise and one `### Step <label> — SQL | Written answer | Terminal | Python (<box id>)`
  per box, with the box's text in a fenced block and, for SQL/Terminal/Python, the **stored last result** as a
  Markdown table (first 200 rows, then "… n more rows") or fenced text with its timestamp. An optional box reads
  `### Step 4 (optional) — …`. Word-labelled steps use the word: 1-34's written answer is
  `### Step notice — Written answer (a1-34-notice)`;
- `## Terminal transcript` — everything ever run in the Terminal on that page, including the schema
  `load_data.py` printed, with the file-sync notes after each exit line;
- `## Python cell` — the cell text and its last output;
- `## Database at export time` — per database, every table with its row count and its `CREATE TABLE` statement in
  a `sql` fence. A view is listed by name with `view` in place of a count.

**Honesty markers.** The page never claims a result it does not have. You will see:

| Marker | What it means |
|---|---|
| `_(no answer)_` | a required box was left empty |
| `_(optional — not attempted)_` | an untouched optional box — fine, costs nothing |
| `_(written but never run — press Run before exporting)_` | SQL (or Python cell) text with no stored result |
| `_(this result is from an earlier version of the box — press Run again to refresh it)_` | the text was edited after its last Run, so the shown result may not match the SQL above it |
| `_(not run yet — put the command in the Terminal and press Run)_` | a terminal step whose command was never run |

The export contains no file paths (the pages never write `file://` or a local path into it).

## Grading from the export

The results in the `.md` are the page's real output at the moment the student pressed Run — but the file is
written to the student's computer, so it is editable. Spot-check by opening the submitted `.db` (DB Browser for
SQLite, `sqlite3`, or a page's **Open a .db file…** button) and re-running a query or two; every `-- @step` block
in `solutions-chN.sql` is paste-ready and its expected row count is in the comment. A box marked *never run* or
*earlier version* is a box whose result you cannot trust: grade the SQL text on its own.

**Chapter 1.** The Terminal transcript must show both imports — the first with `zip INTEGER`, the re-import
(step 4, `--text-columns zip frequent_flier_number`) with `zip TEXT` — and `campus_travel.db` should hold 43 rows
in `frequent_fliers` with the seating typo fixed.

- **Step 6 re-runs are full credit.** The page invites re-running a box after a reload or an edit, and the
  step-6 box holds the `UPDATE` *and* the re-run of query (e). On a second Run the `UPDATE` matches nothing that
  is left, so the stored result reads `OK · 0 rows changed` followed by the corrected three-row count. That is
  the correct output for a student who already applied the fix, not a missing `UPDATE` — the submitted `.db` is
  the evidence, and it will have `Emergency Exit` spelled correctly in 6 rows.
- If the `.db` still holds `Emgerency Exit` while the step-6 box shows `OK · 6 rows changed`, they re-imported
  after fixing it (step 4's command rebuilds the table). Wrong order, not no work.
- **1-34's "One thing to notice" box is graded** — it is a written answer (`a1-34-notice`) and part of the
  20-point written-answers line. Credit any answer that identifies the denominator as the issue: 2.31 is per
  *sale*, while per salesperson it is 81 ÷ 6 = 13.5 for the quarter. A restated 2.31 with no reasoning earns
  nothing.

**Chapter 2, step 4 — the `PRAGMA foreign_key_check` rule.** This is a stronger check than the old heuristic, and
it needs one nuance. Run `PRAGMA foreign_key_check;` against the submitted `mileage.db` (block
`s2-37-4-orphan-check`):

- **No rows** — every foreign-key insert they wrote about really failed, or they cleaned up as the step says.
  Grade the pasted error text on its merits.
- **One or more rows** — an insert that "should have failed" was accepted and the orphan is still in `flights`.
  That is *not* proof of fabrication on its own. Look at the box before deciding. Each Run opens a fresh
  connection, so `PRAGMA foreign_keys = ON;` only counts when it sits in the same box as the INSERT it protects;
  and because the page stops at the first error, a cleanup `DELETE` written *below* the failing INSERT never
  runs. So a box showing the PRAGMA above the INSERT with a stored `Statement 2 failed: FOREIGN KEY constraint
  failed` means the error **was** observed and only the cleanup was missed: a small deduction, not the fabricated
  case. Only a box with no PRAGMA, or a pasted error the page could not have produced, is the fabricated case —
  and that is worth a conversation rather than a penalty, because it is a real and famous SQLite gotcha.

The step's second box (`s2-37-4b`) is optional; `_(optional — not attempted)_` in the export is fine. The
export's "Database at export time" section shows the `CREATE TABLE` statements, so the constraints themselves are
graded without opening the file.

**Chapter 3.** `employees.db` is seeded by the page from the embedded original (24 rows) and Reset database
restores it, so the submitted file and the export's "Database at export time" `CREATE TABLE` are the only trace
of the step-5 `ALTER TABLE`.

- **Step 3 returns zero rows, and the empty result is the finding.** Lewiston has two staff — Proctor
  (Continental) and Weber (American Airlines) — so nobody there covers British Airways. The graded work is the
  two or three sentences in `a3-41-3` saying the call has to go to one of the seven experts elsewhere. A student
  who reports "the query didn't work" has missed the exercise; the page's chips deliberately carry no row count
  here, and Getting unstuck says in as many words that an empty result is still a result.

## Re-run traps worth flagging in class

Both are documented on the pages, and both produce a confusing-but-correct state that students report as a bug:

- **Re-running 2-37 step 2 empties the three tables.** The box keeps its `DROP TABLE IF EXISTS` lines, so a
  re-run rebuilds `airlines`, `customers` and `flights` from empty and every step-5 query returns nothing. Step 3
  has to be run again. The step says so, step 3's chips say so, and Getting unstuck has an entry. The loss is not
  silent either: dropping a table that had rows adds a `Dropped flights (15 rows)` line to the output, which is
  the line to point at when a student says the data "just disappeared".
- **Re-running the 1-35 step-4 import reinstates the misspelling.** Each import rebuilds `frequent_fliers` from
  the text file, so the step-6 `UPDATE` has to be run again afterwards. Chapter 1's Getting unstuck list leads
  with it.

## Files here

| File | What it is |
|---|---|
| `ANSWER-KEY.md` | Every answer, computed from the shipped data — not estimated. Figures are unchanged from the previous edition; the step notes say what the browser changes. |
| `solutions-ch1.sql`, `solutions-ch2.sql`, `solutions-ch3.sql` | The reference SQL, split into blocks by `-- @step <box id>` markers (one block per graded SQL box, named after the box on the page: `s1-35-5a`, `s2-37-4-check`, …) and `-- @alt <id>` blocks (reference material that is not driven). The `@step` blocks are exactly what the automated verification pastes into the pages. |
| `expected/chapter-1.json`, `chapter-2.json`, `chapter-3.json` | Ordered verification scripts (no SQL inside): which block goes into which box, the expected row counts, spot cells, error texts, table counts, what the downloaded `.db` and exported `.md` must contain, reload/reset/XSS/offline checks. |
| `BLACKBOARD-TEXT.md` | Copy-paste replacement text for the Blackboard items and the attachment swap. |

## Regenerating and verifying

The pages, the handout PDF and both zips are **generated** from `hw/src/` (never shipped): the exercise text is
in `hw/src/content/chapter-N.mjs`, the handout front/back matter in `hw/src/content/handout.mjs`. Do not edit the
built pages by hand — `check.mjs` reports a page that no longer matches its content as stale. One command runs
the whole cycle in the only order that works:

```bash
node hw/src/all.mjs        # build → static checks → unit tests → headless Chrome → PDF → zips → checks
```

`hw/src/README.md` is the maintainer's document: every option, what each step proves, the content schema, the
`@step`/`expected.json` contract and the gotchas are there and are not repeated here. The one thing to remember
before shipping: if you change a solution block or an expected figure, run `all.mjs` again — `verify-browser.mjs`
drives the real pages with these solutions and will fail on a figure that no longer matches.

## Manual smoke checklist (Firefox and Safari)

Chrome/Edge is the supported target and the only one the automated run covers, so Firefox and Safari are checked
by hand once per edition. Ten minutes with chapter 1, opened from the unzipped folder as a `file://` page:

1. **The page opens and SQLite goes green.** The two loader scripts carry `integrity` + `crossorigin`; a browser
   that refuses them shows the engine strip in its error state with Retry, which is the honest failure but not
   the one we ship.
2. **Run a SQL box** (paste 5a from `solutions-ch1.sql`) — a result table appears under it.
3. **Step 1 in the Terminal** — the first Python action downloads about 12 MB and can take a minute; it must end
   with `Loaded 43 rows` and the table must appear in Tables.
4. **Reload the page.** The name, the box text and the result come back with the "Result from …" caption, and
   the row count survives. Safari has historically restricted `localStorage` on `file://` URLs: if it is blocked,
   the page must still work for the session and say so in the status line rather than fail silently. Anything
   else is a bug worth reporting.
5. **Export my work and Download** both write a file. Open the `.md` and confirm it holds the box and its result.
6. **Type a ten-line answer into a written-answer box** — it must grow to fit, not scroll or clip. (`field-sizing:
   content` does the work in Chrome; the JS fallback is what these two browsers exercise.)
7. **Print preview.** Every box and result is fully visible and nothing is clipped. Expect no
   "Week 1 · Chapter N · version …" running footer: `@page` margin boxes are Chrome/Edge only, and the hero still
   carries the chapter line.
8. **Reset database, then Clear my work** — the confirm text is the page-specific one, and Cancel leaves the
   status reading `Cancelled — nothing changed`.

## History: the Access → SQLite conversion

The three database exercises originally required Microsoft Access, which is Windows-only, is not in the Keiser
Microsoft 365 student allocation, and cannot open a `.accdb`/`.mdb` file on a Mac at all. The first conversion
moved them to SQLite files worked on in DB Browser for SQLite with a locally installed Python; this edition moves
the same exercises into the browser so nothing is installed. The three spreadsheet exercises are unchanged
throughout.

| Exercise | Was | Now |
|---|---|---|
| 1-34 Ticket Sales | Excel | Excel — unchanged, plus SUMIF summaries, a chart, and a written answer on the page |
| 1-35 Frequent Fliers | **Access** import of `FrequentFliers.txt` | `load_data.py` in the page's Terminal → SQLite, six queries, plus a data-type question and a data-cleaning UPDATE |
| 2-36 TCO | Excel | Excel — unchanged, plus a %-of-total column, two charts, and two written answers on the page |
| 2-37 Frequent-Flier DB | **Access**, built from scratch | SQLite, built from scratch in the page's SQL boxes — a three-table design with real constraints |
| 3-40 Mileage | Excel `.xls` | Excel `.xlsx` (converted), plus a tier system with nested IF and a written answer on the page |
| 3-41 Knowledge DB | **Access** `employeedata.mdb` | SQLite `employees.db` (converted, embedded in the page), plus a coverage-gap query |

**The two file conversions.** `employeedata.mdb` → `employees.db` was extracted with `mdbtools`: one table,
`Employees`, 24 rows, five columns (`LastName`, `FirstName`, `Office`, `Expertise`, `Home Phone`); nothing was
edited, and `data/employees.csv` holds the same data as text. `frequentflier2.xls` → `frequentflier2.xlsx` kept
both worksheets with their names, `Customers` (43 rows, `Miles Flown` column deliberately empty) and
`Miles Flown` (43 lookup rows); headers bolded, columns widened, top row frozen, no values changed.

**Three things worth knowing before you grade.** The `Emgerency Exit` typo is real — it is misspelled in the
original `FrequentFliers.txt` in 6 of 43 rows, and Exercise 1-35 step 6 makes students find and fix it with an
`UPDATE` rather than shipping clean data. The Lewiston query (3-41 step 3) returns zero rows on purpose, and the
empty result is the answer. Exercise 2-37 step 4 catches fabricated output — a foreign-key failure can only be
seen with `PRAGMA foreign_keys = ON;` in the same box, and `PRAGMA foreign_key_check` on the submitted file shows
whether the "failing" insert really failed, with the nuance above.

**Difficulty.** The added material is meaningfully harder than the Access original, in 2-37 (schema design with
constraints) and 3-41 step 4 (the `CROSS JOIN` / `LEFT JOIN … IS NULL` coverage-gap query). Both hard steps now
carry a note to students, and both are worded as an expectation to attempt rather than as optional:

| Step | The note students see |
|---|---|
| 2-37 step 4 | "This is the step that separates designs; take it seriously even if it takes a few tries." |
| 3-41 step 4 | "This is the hardest query in the assignment; attempt it seriously even if you do not finish it." |

Both notes are on the page and in the handout. Note that 2-37 as a whole is still the steeper jump from the
Access original — the note sits on step 4, but the design work in steps 2 and 3 is what students have never done
before — so watch the first cohort's step-4 and step-5b results before deciding the exercise lands. If a first
run proves too steep, the cleanest cuts are 3-41 step 4 and 2-37 step 4.

**Verification.** Every figure in the answer key was recomputed from the shipped data with python3 and the sqlite3
CLI, and the browser run (`verify-browser.mjs`) executes every solution block on the real pages and compares row
counts, spot cells and error texts against `expected/chapter-N.json` before the zips are built.
