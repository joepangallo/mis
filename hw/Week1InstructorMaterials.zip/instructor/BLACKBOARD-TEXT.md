# Blackboard replacement text (browser edition)

Copy-paste ready. Four items to change in the Week 1 folder.

---

## 1. Rename the three assignment items

| Current title | New title |
|---|---|
| Week 1 Chapter 1 Access and Excel Projects | Week 1 Chapter 1 Excel and SQLite Projects |
| Week 1 Chapter 2 Access and Excel Projects | Week 1 Chapter 2 Excel and SQLite Projects |
| Week 1 Chapter 3 Access and Excel Projects | Week 1 Chapter 3 Excel and SQLite Projects |

The closing line of the exercise document also refers to "Access and Excel Projects below" —
the replacement text in section 3 already says "Excel and SQLite Projects".

---

## 2. Instructions for each assignment item

**Chapter 1 item:**

> Submit your Week 1 Chapter 1 Application Exercises as a single zip file.
>
> Your zip should contain:
> - `TicketSales.xlsx` — Exercise 1-34, with formulas intact
> - `campus_travel.db` — Exercise 1-35, your SQLite database (the Download button on the chapter page)
> - `ch1-queries.md` — made by the chapter page's **Export my work** button: the import schema, your written
>   answers, and every query with its result
>
> Press Run on every SQL box before you export, so the export shows your results. Save spreadsheets as `.xlsx`,
> not `.csv` — a `.csv` file cannot store a formula, and the formulas are most of what is graded. Submit the
> `.db` file itself, not screenshots of it.

**Chapter 2 item:**

> Submit your Week 1 Chapter 2 Application Exercises as a single zip file.
>
> Your zip should contain:
> - `TCO.xlsx` — Exercise 2-36, with formulas and both charts
> - `mileage.db` — Exercise 2-37, the database you designed (the Download button on the chapter page)
> - `ch2-database.md` — made by the chapter page's **Export my work** button: your CREATE TABLE statements, your
>   failed-insert evidence, all five queries with results, and your written comparison
>
> Press Run on every SQL box before you export. Save spreadsheets as `.xlsx`, not `.csv`. Submit the `.db` file
> itself, not screenshots of it.

**Chapter 3 item:**

> Submit your Week 1 Chapter 3 Application Exercises as a single zip file.
>
> Your zip should contain:
> - `frequentflier2.xlsx` — Exercise 3-40, with your VLOOKUP formulas and Status column
> - `employees.db` — Exercise 3-41, including your ALTER TABLE change (the Download button on the chapter page)
> - `ch3-queries.md` — made by the chapter page's **Export my work** button: every query with its result, and your
>   written answers
>
> Press Run on every SQL box before you export. Save spreadsheets as `.xlsx`, not `.csv`. Submit the `.db` file
> itself, not screenshots of it.

---

## 3. Replacement text for the "Application Exercises - Week 1" document

Replace the body of the existing document with this. It is the short version — the full
step-by-step specification is in the attached handout and on the three chapter pages, which is
what students actually work from.

> ## Application Exercises — Week 1
>
> Download `Week1StarterFiles.zip` and unzip it into a folder called **Week 1**. Inside are three web pages,
> one per chapter — `week-1-chapter-1.html`, `week-1-chapter-2.html`, `week-1-chapter-3.html` — the data
> files, and the handout as a PDF.
>
> **Start with `Application-Exercises-Week-1.pdf`.** It contains the full instructions for all six exercises,
> the setup notes, and the grading breakdown. You do not need the textbook to complete these, you do not need
> Microsoft Access, and you do not need to install anything.
>
> **Software you need — two things, and there is nothing to install:**
> - A laptop or Chromebook with a current **Chrome or Edge** (Firefox and Safari should also work; phones and
>   iPads are not supported for the database exercises). Open each chapter page from the unzipped folder: the
>   SQL boxes, the Terminal, and your database all run inside the page. You need internet access the first time
>   you open a page (it downloads its database engine, and Python the first time you use it).
> - **Excel** for the spreadsheet exercises — included with your Keiser Microsoft 365 account. LibreOffice Calc
>   or Google Sheets also work.
>
> You do **not** need to install Python, and you do **not** need DB Browser for SQLite. Both are optional
> fallbacks, described in the handout, for working outside the browser if you prefer.
>
> Your work is saved in that browser on that computer. On a shared computer, use Export my work and Download
> before you leave, then Clear my work.
>
> ### Chapter 1
> - **Spreadsheet — Ticket Sales at Campus Travel (1-34).** Summarise a quarter of ticket
>   sales with SUM, MAX, MIN, AVERAGE and SUMIF, and chart the result. Uses `TicketSales.csv`.
> - **Database — Tracking Frequent-Flier Miles (1-35).** Import the frequent-flier list into
>   a SQLite database with `load_data.py` in the page's Terminal, then answer six questions with SQL and fix a
>   data-quality problem you will find along the way. Uses `FrequentFliers.txt`.
>
> ### Chapter 2
> - **Spreadsheet — Valuing Information Systems (2-36).** Build a total cost of ownership
>   model across five sites, add a percentage-of-total column, and chart it. Uses `TCO.csv`.
> - **Database — Designing the Frequent-Flier Database (2-37).** Design and build a
>   three-table SQLite database from scratch in the page's SQL boxes, with primary keys, foreign keys and
>   constraints, then query it with JOIN and GROUP BY. No data file — you create it.
>
> ### Chapter 3
> - **Spreadsheet — Tracking Frequent-Flier Mileage (3-40).** Match customers to their
>   mileage with VLOOKUP across two worksheets, then build a tier system with nested IF.
>   Uses `frequentflier2.xlsx`.
> - **Database — Building a Knowledge Database (3-41).** Query a staff expertise database to
>   find who knows what, and find the coverage gaps. Uses `employees.db`, already open on the page.
>
> When the exercises are complete, zip each chapter folder separately (the spreadsheet, the downloaded `.db`,
> and the `.md` made by Export my work) and upload them through the matching **Excel and SQLite Projects** item
> below.

---

## 4. Attachments to swap

**Remove:**
- `Ch 3 employeedata.mdb` — needs Microsoft Access, which students do not have
- `Ch 3 frequentflier2.xls` — the Excel 97-2003 format; keeps triggering compatibility warnings

**Add — five files, in this order:**

| Attachment | What it is |
|---|---|
| `Week1StarterFiles.zip` | The whole assignment: the three chapter pages, the data files, `load_data.py`, the prebuilt `employees.db` and the PDF. This is the one students are told to download and unzip into a folder called `Week 1`. |
| `Application-Exercises-Week-1.pdf` | The full student handout — all six exercises, the setup notes, the hand-in table and the grading breakdown. Also inside the zip; post it separately so it can be read without unzipping anything. |
| `week-1-chapter-1.html` | The **Chapter 1** page — Exercises 1-34 (Ticket Sales, Excel) and 1-35 (Frequent Fliers, SQLite). |
| `week-1-chapter-2.html` | The **Chapter 2** page — Exercises 2-36 (TCO, Excel) and 2-37 (Designing the Frequent-Flier Database, SQLite). |
| `week-1-chapter-3.html` | The **Chapter 3** page — Exercises 3-40 (Mileage, Excel) and 3-41 (Knowledge Database, SQLite). |

The three pages are posted individually as well as inside the zip because each one is self-contained: the seven
data files are built into every page with a Download button, so a student who downloads only their chapter's
page can still do the whole chapter, spreadsheet included — `TicketSales.csv`, `TCO.csv` and
`frequentflier2.xlsx` all have Download buttons in the page's Files list. Attach each page to its own chapter
assignment item as well, so nobody opens the wrong chapter.

**Keep as they are (optional):**
- `Ch 1 FrequentFliers.txt`
- `Ch 1 TicketSales.csv`
- `Ch 2 TCO.csv`

(All three are inside the starter zip and are also built into every chapter page's Files list with a Download
button, so keeping them as separate attachments is belt-and-braces rather than necessary.)

**Never attach** anything from the `instructor/` folder or `Week1InstructorMaterials.zip`.
