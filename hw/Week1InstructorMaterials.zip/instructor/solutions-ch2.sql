-- ============================================================
-- Exercise 2-37 — Designing the Frequent-Flier Database
-- Reference schema and reference queries.
-- Students build their own; this is the shape to grade against.
--
-- Browser workflow (week-1-chapter-2.html). Each `-- @step <id>` block
-- below is what verify-browser.mjs pastes into the SQL box named <id>
-- and runs with one press of Run; a block ends at the next marker or at
-- the end of the file. The six step-4 blocks are all driven into the one
-- step-4 box, s2-37-4, in the order they appear here. Blocks marked
-- `-- @alt` are reference material only and are never driven.
--
-- Every Run on the page opens mileage.db fresh, so a PRAGMA in one box
-- has no effect on the next. That is why the foreign-key block carries
-- its own `PRAGMA foreign_keys = ON;` and why there is no longer a
-- global PRAGMA at the top of this file. It also means the same insert
-- run WITHOUT the PRAGMA succeeds (block s2-37-4-fk-nopragma) — the
-- gotcha the answer key warns about; `PRAGMA foreign_key_check` then
-- lists the orphan row and the cleanup block removes it. The cleanup
-- DELETE is its own block on purpose: the page stops at the first
-- error, so a DELETE written below a failing INSERT never runs — a
-- student who did that shows the real error AND an orphan (see the
-- answer key before calling it fabricated).
--
-- The whole file also still runs top to bottom in the sqlite3 CLI:
--     sqlite3 mileage.db < solutions-ch2.sql
-- (the three failing inserts print their errors and the CLI carries on).
-- ============================================================

-- @step s2-37-2
-- The DROP lines make the box safe to re-run: flights first, then
-- customers, then airlines, because each refers to the one after it.
DROP TABLE IF EXISTS flights;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS airlines;

CREATE TABLE airlines (
    airline_id    INTEGER PRIMARY KEY,
    airline_name  TEXT NOT NULL UNIQUE,
    alliance      TEXT
);

CREATE TABLE customers (
    customer_id           INTEGER PRIMARY KEY,
    last_name             TEXT NOT NULL,
    first_name            TEXT NOT NULL,
    phone_number          TEXT,
    frequent_flier_number TEXT UNIQUE,
    airline_id            INTEGER,
    FOREIGN KEY (airline_id) REFERENCES airlines(airline_id)
);

CREATE TABLE flights (
    flight_id    INTEGER PRIMARY KEY,
    customer_id  INTEGER,
    flight_date  TEXT,
    origin       TEXT,
    destination  TEXT,
    miles        INTEGER NOT NULL CHECK (miles > 0),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- @step s2-37-3
-- Reference data: 4 airlines, 7 customers, 15 flights.
INSERT INTO airlines (airline_id, airline_name, alliance) VALUES
    (1, 'American Airlines', 'Oneworld'),
    (2, 'British Airways',   'Oneworld'),
    (3, 'Delta',             'SkyTeam'),
    (4, 'United',            'Star Alliance');

INSERT INTO customers (customer_id, last_name, first_name, phone_number, frequent_flier_number, airline_id) VALUES
    (1, 'Nauman',   'Michael', '509-357-5673', 'FF742971', 2),
    (2, 'Looney',   'Carl',    '509-222-5645', 'FF401419', 1),
    (3, 'Cox',      'Linda',   '509-332-7456', 'FF472458', 1),
    (4, 'Proctor',  'Ginny',   '208-875-3333', 'FF525630', 3),
    (5, 'Choi',     'Diane',   '208-882-5478', 'FF224029', 2),
    (6, 'Frazier',  'Nancy',   '509-332-1243', 'FF294736', 4),
    -- Enrolled but has never flown. This row is deliberate: it is what makes
    -- LEFT JOIN in query (b) give a different answer from JOIN. Keep an
    -- equivalent row when grading a student database that lacks one.
    (7, 'Baker',    'Beth',    '509-555-8947', 'FF219608', 3);

INSERT INTO flights (customer_id, flight_date, origin, destination, miles) VALUES
    (1, '2025-01-14', 'PUW', 'SEA',  228),
    (1, '2025-02-03', 'SEA', 'LHR', 4783),
    (1, '2025-04-22', 'LHR', 'SEA', 4783),
    (2, '2025-01-30', 'GEG', 'DFW', 1519),
    (2, '2025-03-11', 'DFW', 'MIA', 1121),
    (2, '2025-06-08', 'MIA', 'GEG', 2492),
    (3, '2025-02-17', 'PUW', 'SEA',  228),
    (3, '2025-05-02', 'SEA', 'ORD', 1721),
    (4, '2025-03-19', 'LWS', 'SLC',  454),
    (4, '2025-07-14', 'SLC', 'ATL', 1590),
    (5, '2025-04-05', 'GEG', 'JFK', 2364),
    (5, '2025-08-21', 'JFK', 'LHR', 3451),
    (6, '2025-02-28', 'PUW', 'DEN',  832),
    (6, '2025-06-15', 'DEN', 'SFO',  967),
    (6, '2025-09-09', 'SFO', 'PUW',  693);

-- ------------------------------------------------------------
-- Step 4: inserts that MUST fail. Students record the real error.
-- One block per Run; the page reports "Statement k failed: <message>".
-- ------------------------------------------------------------

-- @step s2-37-4-check
-- Expect: CHECK constraint failed: miles > 0
--         (older SQLite says: CHECK constraint failed: flights)
INSERT INTO flights (customer_id, flight_date, origin, destination, miles)
VALUES (1, '2025-10-01', 'PUW', 'SEA', -100);

-- @step s2-37-4-unique
-- Expect: UNIQUE constraint failed: customers.frequent_flier_number
INSERT INTO customers (last_name, first_name, frequent_flier_number, airline_id)
VALUES ('Duplicate', 'Test', 'FF742971', 1);

-- @step s2-37-4-fk-nopragma
-- Expect: OK · 1 rows changed. Foreign keys are OFF on a fresh connection,
-- so SQLite ACCEPTS this row; flights now has 16 rows and one orphan. A
-- student who reports "FOREIGN KEY constraint failed" for a box like this
-- did not run it — see the orphan check below.
INSERT INTO flights (customer_id, flight_date, origin, destination, miles)
VALUES (999, '2025-10-01', 'PUW', 'SEA', 500);

-- @step s2-37-4-fk-pragma
-- Expect: Statement 2 failed: FOREIGN KEY constraint failed
-- The PRAGMA must sit in the same box as the INSERT it protects.
PRAGMA foreign_keys = ON;
INSERT INTO flights (customer_id, flight_date, origin, destination, miles)
VALUES (999, '2025-10-01', 'PUW', 'SEA', 500);

-- @step s2-37-4-orphan-check
-- Expect: 1 row — table flights, the stray rowid, parent customers.
-- Run this against a submitted mileage.db too: any row here means a
-- "failing" foreign-key insert did not actually fail.
PRAGMA foreign_key_check;

-- @step s2-37-4-cleanup
-- Expect: OK · 1 rows changed; flights is back to 15 rows and the
-- orphan check above returns nothing.
DELETE FROM flights WHERE customer_id = 999;

-- ------------------------------------------------------------
-- Step 5: reference queries (run against the 4 / 7 / 15 reference data)
-- ------------------------------------------------------------

-- @step s2-37-5a
-- (a) Customers with their airline name.  Expect 7 rows, Baker first.
SELECT c.first_name, c.last_name, a.airline_name
FROM customers c
JOIN airlines a ON c.airline_id = a.airline_id
ORDER BY c.last_name;

-- @step s2-37-5b
-- (b) Total miles per customer, INCLUDING customers with no flights.
--     LEFT JOIN is required here; a plain JOIN silently drops them.
--     Expect 7 rows: Nauman 9794 first … Baker 0 last.
SELECT c.first_name,
       c.last_name,
       COALESCE(SUM(f.miles), 0) AS total_miles
FROM customers c
LEFT JOIN flights f ON f.customer_id = c.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name
ORDER BY total_miles DESC;

-- @step s2-37-5c
-- (c) Total miles per airline.  Expect 4 rows:
--     British Airways 15609 · American Airlines 7081 · United 2492 · Delta 2044
SELECT a.airline_name, COALESCE(SUM(f.miles), 0) AS total_miles
FROM airlines a
LEFT JOIN customers c ON c.airline_id = a.airline_id
LEFT JOIN flights   f ON f.customer_id = c.customer_id
GROUP BY a.airline_id, a.airline_name
ORDER BY total_miles DESC;

-- @step s2-37-5d
-- (d) Flights over 1,000 miles.  Expect 9 rows, SEA - LHR 4783 first.
SELECT c.first_name, c.last_name, f.flight_date,
       f.origin || ' - ' || f.destination AS route,
       f.miles
FROM flights f
JOIN customers c ON c.customer_id = f.customer_id
WHERE f.miles > 1000
ORDER BY f.miles DESC;

-- @step s2-37-5e
-- (e) The single highest-mileage customer.  Expect 1 row: Michael Nauman 9794.
SELECT c.first_name, c.last_name, SUM(f.miles) AS total_miles
FROM customers c
JOIN flights f ON f.customer_id = c.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name
ORDER BY total_miles DESC
LIMIT 1;
