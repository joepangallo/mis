-- ============================================================
-- Exercise 3-41 — Knowledge Database — solution queries
-- Database: chapter-03/employees.db, table employees (24 rows)
-- Converted from the original Access file employeedata.mdb.
--
-- Browser workflow. Students do this exercise on the page
-- Week 1/week-1-chapter-3.html: SQLite runs inside the browser,
-- employees.db is opened for them (the page's seed database), and
-- each SQL box is run against it. Every Run opens the stored
-- database file fresh, runs the box top to bottom, and saves the
-- file again; "Reset database" puts the original 24-row file back.
-- Students hand in Download employees.db plus ch3-queries.md, which
-- "Export my work" writes (every box's SQL and its last result).
--
-- Block markers. `-- @step <workspace id>` starts a block that
-- verify-browser.mjs pastes into the page's SQL box with that id
-- (expected results live in expected/chapter-3.json — no SQL there).
-- `-- @alt <id>` starts a reference-only block that is never driven.
-- A block ends at the next marker or at the end of the file. Nothing
-- here depends on a PRAGMA or on state left by an earlier block, apart
-- from the step-5 ALTER, which is why it is driven last.
--
-- To run this file outside the browser (a scratch copy only):
--   cp "Week 1/chapter-03/employees.db" /tmp/employees.db
--   sqlite3 /tmp/employees.db < solutions-ch3.sql
-- ============================================================

-- @step s3-41-2a
-- (a) British Airways experts.  Expect 7 rows:
--     Boyd/Pullman · Choi/Moscow · Henderson/Pullman · Nauman/Colfax
--     Stewart/Colfax · Thornton/Pullman · Walker/Pullman
SELECT firstname, lastname, office, home_phone
FROM employees
WHERE expertise = 'British Airways'
ORDER BY lastname;

-- @step s3-41-2b
-- (b) Head count per office.  Expect: Pullman 12 · Moscow 5 · Colfax 5 · Lewiston 2
SELECT office, COUNT(*) AS staff
FROM employees
GROUP BY office
ORDER BY staff DESC;

-- @step s3-41-2c
-- (c) Head count per expertise.  Expect: British Airways 7 · American Airlines 7
--     · Delta 5 · Continental 5
SELECT expertise, COUNT(*) AS staff
FROM employees
GROUP BY expertise
ORDER BY staff DESC;

-- @step s3-41-2d
-- (d) The Pullman office.  Expect 12 rows.
SELECT firstname, lastname, expertise, home_phone
FROM employees
WHERE office = 'Pullman'
ORDER BY expertise, lastname;

-- @step s3-41-2e
-- (e) Delta or Continental, using IN.  Expect 10 rows.
SELECT firstname, lastname, office, expertise
FROM employees
WHERE expertise IN ('Delta', 'Continental')
ORDER BY expertise, lastname;

-- @step s3-41-2f
-- (f) Expertise within Pullman.  Expect 4 rows:
--     British Airways 4 · American Airlines 4 · Delta 2 · Continental 2
SELECT expertise, COUNT(*) AS staff
FROM employees
WHERE office = 'Pullman'
GROUP BY expertise
ORDER BY staff DESC;

-- @step s3-41-3
-- ------------------------------------------------------------
-- (3) The Lewiston / British Airways call.
--     The point of the question: Lewiston has 2 staff, neither of whom
--     covers British Airways (Proctor = Continental, Weber = American).
--     A correct query returns ZERO rows, and the student must recognise
--     that an empty result is itself the finding — the call has to be
--     routed to another office. Full credit requires naming that.
--     On the page the result reads "Result 1 · 0 rows"; the Getting
--     unstuck list tells students an empty result is still a result.
-- ------------------------------------------------------------
SELECT firstname, lastname, office, home_phone
FROM employees
WHERE office = 'Lewiston' AND expertise = 'British Airways';
-- 0 rows.

-- @alt 3-41-3-followup
-- The useful follow-up a strong student will write unprompted:
SELECT firstname, lastname, office, home_phone
FROM employees
WHERE expertise = 'British Airways'
ORDER BY office, lastname;

-- @step s3-41-4
-- ------------------------------------------------------------
-- (4) Coverage gaps: office/expertise pairs that do not exist.
--     4 offices x 4 airlines = 16 possible pairs; 12 exist; 4 are missing.
--     Expect exactly 4 rows:
--       Colfax   / Continental
--       Lewiston / British Airways
--       Lewiston / Delta
--       Moscow   / American Airlines
-- ------------------------------------------------------------
SELECT o.office, x.expertise
FROM (SELECT DISTINCT office FROM employees) AS o
CROSS JOIN (SELECT DISTINCT expertise FROM employees) AS x
LEFT JOIN employees e
       ON e.office = o.office AND e.expertise = x.expertise
WHERE e.lastname IS NULL
ORDER BY o.office, x.expertise;

-- @alt 3-41-4-not-exists
-- Equivalent form, accept either:
SELECT o.office, x.expertise
FROM (SELECT DISTINCT office FROM employees) AS o
CROSS JOIN (SELECT DISTINCT expertise FROM employees) AS x
WHERE NOT EXISTS (
    SELECT 1 FROM employees e
    WHERE e.office = o.office AND e.expertise = x.expertise
);

-- @step s3-41-5
-- ------------------------------------------------------------
-- (5) Adding a primary key.
--     SQLite cannot add a PRIMARY KEY with ALTER TABLE, so accept either
--     the simple ALTER (which adds the column but not the constraint) or
--     the full rebuild. A student who notices the limitation and says so
--     has understood more than one who does not.
--     On the page: the ALTER prints "OK", the UPDATE prints
--     "OK · 24 rows changed", and Structure shows the new column.
--     Running this box twice fails ("duplicate column name") — that is
--     harmless; Reset database puts the original file back.
-- ------------------------------------------------------------
ALTER TABLE employees ADD COLUMN employee_id INTEGER;
UPDATE employees SET employee_id = rowid;

-- @alt 3-41-5-rebuild
-- The rebuild that actually enforces it:
CREATE TABLE employees_new (
    employee_id INTEGER PRIMARY KEY,
    lastname    TEXT NOT NULL,
    firstname   TEXT NOT NULL,
    office      TEXT,
    expertise   TEXT,
    home_phone  TEXT
);
INSERT INTO employees_new (employee_id, lastname, firstname, office, expertise, home_phone)
SELECT rowid, lastname, firstname, office, expertise, home_phone FROM employees;
DROP TABLE employees;
ALTER TABLE employees_new RENAME TO employees;

-- @alt 3-41-6-discussion
-- ------------------------------------------------------------
-- (6) Discussion — what the database does not capture.
--     Look for any two of:
--       * Expertise is a single value per person. Real staff know several
--         airlines to varying degrees; there is no room for a second one,
--         and no room for a proficiency level.
--       * Nothing records WHO decided a person is the Delta expert, when,
--         or on what evidence. Self-reported expertise and verified
--         expertise are being stored identically.
--       * Nothing decays. An expert who has not touched Delta in three
--         years still reads as current.
--       * There is no actual knowledge in the knowledge database — it
--         points at people, so it fails the moment someone leaves. The
--         answers themselves are still only in their heads.
--       * Only home phone numbers are stored, which is a privacy question
--         as much as a design one.
--     A strong answer connects one of these to the office/expertise gap
--     found in step 4: the schema cannot express "partly covered".
-- ------------------------------------------------------------
