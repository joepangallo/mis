-- ============================================================
-- Exercise 1-35 — Frequent-Flier Database — solution queries
-- Database: campus_travel.db, table frequent_fliers (43 rows)
--
-- Browser edition. Students build the database on week-1-chapter-1.html:
--   step 1, in the page's Terminal (zip and frequent_flier_number come in as INTEGER):
--     python load_data.py chapter-01/data/FrequentFliers.txt frequent_fliers campus_travel.db
--   step 4, the re-import that forces both identifier columns to TEXT:
--     python load_data.py chapter-01/data/FrequentFliers.txt frequent_fliers campus_travel.db \
--            --text-columns zip frequent_flier_number
-- Every query below runs unchanged in the page's SQL boxes, in DB Browser for
-- SQLite, or in the sqlite3 command line against the same file.
--
-- Block markers. `-- @step <workspace id>` starts the block that
-- src/verify-browser.mjs pastes into that SQL box on the student page
-- (exactly one block per required SQL workspace; the expected results are in
-- expected/chapter-1.json). `-- @alt <id>` starts an example block that is
-- never driven. A block runs from its marker to the next marker or the end of
-- the file. Each Run on the page opens the database fresh, so a block must be
-- self-contained.
-- ============================================================

-- @step s1-35-5a
-- (a) Vegan customers, sorted by last name.  Expect 13 rows.
SELECT first_name, last_name, airline
FROM frequent_fliers
WHERE meal_category = 'Vegan'
ORDER BY last_name;

-- @step s1-35-5b
-- (b) Count per meal category, highest first.  Expect 4 rows:
--     Vegan 13 · Kosher 11 · Islamic/halal 10 · Non Veg 9
SELECT meal_category, COUNT(*) AS customers
FROM frequent_fliers
GROUP BY meal_category
ORDER BY customers DESC;

-- @step s1-35-5c
-- (c) Count per airline, highest first.  Expect 4 rows:
--     American Airlines 15 · Continental 10 · Delta 9 · British Airways 9
SELECT airline, COUNT(*) AS customers
FROM frequent_fliers
GROUP BY airline
ORDER BY customers DESC;

-- @step s1-35-5d
-- (d) Idaho customers who prefer a window seat.  Expect 1 row: Diane Choi, Moscow.
SELECT first_name, last_name, city, phone_number
FROM frequent_fliers
WHERE state = 'ID' AND seating_area = 'Window';

-- @step s1-35-5e
-- (e) Count per seating preference.  BEFORE the fix, expect 3 rows:
--     Window 19 · Aisle 18 · Emgerency Exit 6
SELECT seating_area, COUNT(*) AS customers
FROM frequent_fliers
GROUP BY seating_area
ORDER BY customers DESC;

-- @step s1-35-6
-- (6) The data-quality fix. 'Emgerency Exit' is misspelled in the source file
--     and appears in 6 rows. Accept any UPDATE that corrects all six.
--     The page reports "OK · 6 rows changed" for the UPDATE.
UPDATE frequent_fliers
SET seating_area = 'Emergency Exit'
WHERE seating_area = 'Emgerency Exit';

-- Re-run (e).  AFTER the fix: Window 19 · Aisle 18 · Emergency Exit 6
SELECT seating_area, COUNT(*) AS customers
FROM frequent_fliers
GROUP BY seating_area
ORDER BY customers DESC;

-- @step s1-35-7
-- Which city sends us the most frequent fliers?
-- (7) Student's own GROUP BY question. Any defensible question earns credit
--     provided the SQL answers the question actually stated, and the question
--     is on the first line as a SQL comment (as above). Example: Pullman 19, 6 rows.
SELECT city, COUNT(*) AS customers
FROM frequent_fliers
GROUP BY city
ORDER BY customers DESC;

-- @alt 1-35-7-example-2
-- Do meal preferences differ by airline?   (16 rows)
SELECT airline, meal_category, COUNT(*) AS customers
FROM frequent_fliers
GROUP BY airline, meal_category
ORDER BY airline, customers DESC;
