# Week 1 Application Exercises — Answer Key

**Instructor copy. Do not distribute.**

Every figure below was computed directly from the shipped data files, not estimated. The figures are
unchanged from the previous (DB Browser) edition; what changed is where the work happens and what is handed in.

**Browser edition, in one paragraph.** Students do the database exercises on the chapter pages
(`week-1-chapter-N.html`), where SQLite and Python run inside the browser. Every SQL step has its own box; each
press of Run reopens the page's `.db`, runs the whole box, and saves it. They hand in the downloaded `.db` and
`chN-*.md`, a Markdown file written by the page's **Export my work** button that holds every box with its stored
result, the Terminal transcript (including the schema `load_data.py` printed) and a "Database at export time"
summary. Markers in that file tell you when there is no trustworthy result: `_(no answer)_` (an empty required
box), `_(written but never run — press Run before exporting)_`, `_(this result is from an earlier version of the
box — press Run again to refresh it)_` (the SQL was edited after its last Run) and `_(not run yet — put the
command in the Terminal and press Run)_`; `_(optional — not attempted)_` marks an untouched optional box and
costs nothing. The results are the page's real output, but the file is editable — spot-check against the
submitted `.db` with the paste-ready `-- @step` blocks in `solutions-chN.sql`.

---

## 1-34 · Ticket Sales (Excel)

35 data rows. The four summary cells:

| Label | Formula | Answer |
|---|---|---|
| Total Tickets Sold | `=SUM(D2:D36)` | **81** |
| Most Tickets Sold | `=MAX(D2:D36)` | **6** |
| Least Tickets Sold | `=MIN(D2:D36)` | **1** |
| Average Number of Tickets Sold | `=AVERAGE(D2:D36)` | **2.3143** (2.31) |

**Totals by salesperson** (`=SUMIF($B$2:$B$36, <name>, $D$2:$D$36)`):

| Salesperson | Tickets |
|---|---|
| Lisa | 20 |
| Vivien | 20 |
| John | 16 |
| Bob | 11 |
| Andrew | 9 |
| Heather | 5 |

Lisa and Vivien tie at 20. Students who report a single "top salesperson" without noticing
the tie have not looked at their own output.

**Totals by destination:**

| Destination | Tickets |
|---|---|
| Thailand or Indonesia | 14 |
| India | 13 |
| Middle East (UAE, Qatar and Oman) | 13 |
| Japan | 12 |
| Hungary and Poland | 11 |
| Egypt and South Africa | 10 |
| France (Paris and Nice) | 8 |

**Common failure.** The four label rows sit directly below the data. A student who selects
`D2:D40` for `SUM` still gets 81 because the label cells are empty, but a student who sorts
without excluding those rows will scramble the sheet. Watch for it.

**One thing to notice (box `a1-34-notice`, the 20-point written answer).** The average of 2.31 is per
*sale*, not per salesperson or per month. Per salesperson the average is 81 ÷ 6 = 13.5 tickets for the
quarter. The page asks "which average would the regional manager actually want, and why?" — the export
writes it as `### Step notice — Written answer (a1-34-notice)`. Rubric for that box: credit any answer that
identifies the denominator as the issue (per sale vs per salesperson or per month) and says which one the
manager would use; a restated 2.31 with no reasoning earns nothing here.

---

## 2-36 · Total Cost of Ownership (Excel)

**Row totals:**

| Category | Total |
|---|---|
| Personnel | $1,370,000 |
| File servers | $271,000 |
| Mail servers | $200,000 |
| UPS | $113,500 |
| Switches / hubs | $95,000 |
| Edge servers/VPN | $80,000 |
| Security/Firewall/Spam | $50,000 |
| Wiring | $45,500 |
| Cable trays, racks | $34,000 |

**Column totals:**

| Site | Total |
|---|---|
| Main campus | $1,236,000 |
| Spokane Campus | $454,000 |
| TriCities Campus | $412,000 |
| Walla Station | $113,500 |
| Prosser Station | $43,500 |

**Grand total: $2,259,000.** Row totals and column totals must both reach this figure.

**% of Total** (step 7), for reference: Personnel 60.6% · File servers 12.0% · Mail servers
8.9% · UPS 5.0% · Switches 4.2% · Edge servers 3.5% · Security 2.2% · Wiring 2.0% · Cable
trays 1.5%.

**Step 5** (box `a2-36-5`)**.** `SUM` ignores text, so `"N/A"` would not break the arithmetic — but `AVERAGE`
would then divide by a different count, and the cell could not be charted. Accept either
observation. The stronger answer is that a blank means "no cost here" while `"N/A"` is
ambiguous between "no cost" and "cost unknown", and the spreadsheet cannot tell them apart.

**Step 10** (box `a2-36-10`)**.** Personnel is 60.6% of the entire budget — more than every piece of hardware
combined. The intended conclusion: consolidating hardware nibbles at 40% of the budget,
while consolidating *staff* is where real money is, and that is a much harder organisational
decision than buying fewer switches. Prosser Station has no personnel line at all, which is
worth asking about. Credit any answer grounded in the student's own percentage column.

---

## 1-35 · Frequent-Flier Database (SQLite)

See `solutions-ch1.sql` for every query. On the page, step 1's import runs in the Database panel's Terminal
(`python load_data.py chapter-01/data/FrequentFliers.txt frequent_fliers campus_travel.db`), and step 4 re-runs it
with `--text-columns zip frequent_flier_number`; both transcripts, with the printed schema, are in the export.
Headline figures:

- Import loads **43 rows** into `frequent_fliers`.
- Meal categories: Vegan 13 · Kosher 11 · Islamic/halal 10 · Non Veg 9.
- Airlines: American Airlines 15 · Continental 10 · Delta 9 · British Airways 9.
- Seating: Window 19 · Aisle 18 · Emgerency Exit 6.
- Idaho + window seat: **one** customer, Diane Choi of Moscow.

**Step 3 (the `zip` question, box `a1-35-3`).** The importer types `zip` as `INTEGER` because every value
in this file is all digits. That is safe here — Washington and Idaho ZIPs have no leading
zero — but a New England ZIP like `02134` would be stored as `2134` and the leading zero
would be gone for good. The general rule students should articulate: if you will never do
arithmetic on it, it is not a number, regardless of what characters it contains. Phone
numbers and frequent-flier numbers are the same category.

**Step 6 (the data-quality fix).** `Emgerency Exit` is misspelled in the source file, in 6
rows. This is a genuine typo in the original course data, not a plant. The fix:

```sql
UPDATE frequent_fliers
SET seating_area = 'Emergency Exit'
WHERE seating_area = 'Emgerency Exit';
```

Students who "fix" it by editing the `.txt` file instead have solved the wrong problem —
point out that the source file is usually something you do not control.

On the page the `UPDATE` and the re-run of query (e) share one box, so a first Run stores
`OK · 6 rows changed` followed by the corrected 3-row result. **A stored `OK · 0 rows changed`
above that same corrected 3-row result is also full credit.** The page invites re-running a box
after a reload or an edit, and on the second Run the `UPDATE` finds nothing left to fix — the
work was already applied. The submitted `.db` is the evidence: it will spell `Emergency Exit`
correctly in all 6 rows. Do not read the zero as a missing `UPDATE`.

A later re-import (step 4's command) rebuilds the table and brings the typo back — the handout warns
about this; a submitted `.db` that still has `Emgerency Exit` next to a step-6 box showing `OK · 6 rows
changed` means the steps were done out of order, not skipped.

---

## 2-37 · Designing the Frequent-Flier Database (SQLite)

No fixed answer; students design and populate their own. See `solutions-ch2.sql` for a
reference schema and reference queries.

**Grade the design, not the data.** Look for:

- `PRIMARY KEY` on all three tables.
- `NOT NULL` on the required columns named in the spec.
- `UNIQUE` on `airline_name` and on `frequent_flier_number`.
- `CHECK (miles > 0)` on `flights`.
- `FOREIGN KEY` declarations on `customers.airline_id` and `flights.customer_id`.

**Step 4 is the one that separates students.** They must actually run a failing insert and
paste the real error text. Typical messages:

```
UNIQUE constraint failed: customers.frequent_flier_number
CHECK constraint failed: miles > 0
FOREIGN KEY constraint failed
```

The foreign-key message is the one to look at twice: SQLite accepts an orphan insert silently
unless `PRAGMA foreign_keys = ON;` ran on the same connection, so a box that reports
`FOREIGN KEY constraint failed` with no PRAGMA above the INSERT reports something the page
could not have produced. That is worth catching, and worth a conversation rather than a
penalty; it is a real and famous SQLite gotcha. The rule below says how to tell that case
from the two innocent ones.

**The `PRAGMA foreign_key_check` rule (browser edition).** On the page, each Run opens the database fresh, so
the PRAGMA only counts if it is in the *same box* as the INSERT it protects — the step says so, and says what to
do when a "failing" insert did not fail (`DELETE FROM flights WHERE customer_id = 999;`). To grade step 4, run
`PRAGMA foreign_key_check;` against the submitted `mileage.db` (`solutions-ch2.sql`, block
`s2-37-4-orphan-check`):

- **no rows** — every foreign-key insert they wrote about really failed (or they cleaned up as the step says);
  grade the pasted error text on its merits;
- **one or more rows** — an insert that should have failed was accepted at least once and the orphan was never
  removed. **A row here is not by itself proof of fabrication.** Read the box before you decide:
  - the box shows `PRAGMA foreign_keys = ON;` **above** the INSERT and the stored output is the real
    `Statement 2 failed: FOREIGN KEY constraint failed` → the error *was* observed. The student appended the
    cleanup `DELETE` below the failing INSERT, where the page never reaches it (the step says so: "anything
    below a failing statement never runs"). Small deduction for the missed cleanup, full credit for the
    evidence.
  - the box shows no PRAGMA at all, or an error text the page could not have produced from that SQL → this is
    the fabricated case above. The constraint knowledge may be fine; the evidence is not.

In neither case do the design marks move: the `FOREIGN KEY` clause is graded from the `CREATE TABLE` statements,
not from whether the orphan row got in.

The second box in step 4 (`s2-37-4b`, "Optional second failing INSERT") is optional: the export writes
`### Step 4 (optional) — SQL (s2-37-4b)` and `_(optional — not attempted)_` when it was never used, which is
fine and costs nothing. Grade it only when it holds a second failing INSERT.

The export's "Database at export time" section shows the `CREATE TABLE` statements, so the `FOREIGN KEY` clauses
themselves are graded from there without opening the file.

**Step 5b requires `LEFT JOIN`.** A plain `JOIN` silently drops customers with zero flights.
If a student's design has every customer flying, ask them to add one who has not, then re-run.

**Step 6** (box `a2-37-6`)**.** Expected: the three-table design records individual flights (the flat table has
nowhere to put them), stores each airline name once so a rename is one update rather than
many, and can express "customer with no flights". What got harder: every interesting question
now needs a `JOIN`, and inserting a customer means the airline has to exist first.

---

## 3-40 · Frequent-Flier Mileage (Excel)

**The lookup.** In `Miles Flown` on the Customers sheet, row 2:

```
=IFERROR(VLOOKUP(D2, 'Miles Flown'!$A$2:$B$44, 2, FALSE), "Not found")
```

All **43 customers match** — `Not found` should appear zero times. Any student reporting
misses has a relative-reference bug in the lookup range, or omitted the `FALSE`.

**Summary figures:**

| | |
|---|---|
| Total miles | **236,629** |
| Average miles | **5,503.00** |
| Highest | **9,266** (Michael Nauman) |
| Lowest | **1,280** (Kathy Stewart) |
| Customers over 5,000 miles | **26** |

**Top five:**

| Customer | Miles |
|---|---|
| Michael Nauman | 9,266 |
| Carl Looney | 9,222 |
| Eric Hutchinson | 9,205 |
| Mark Dumont | 9,081 |
| Patricia Gillespie | 8,693 |

**Status column** (`=IF(E2>=7500,"Gold",IF(E2>=5000,"Silver","Standard"))`):
Gold **15** · Silver **11** · Standard **17**.

**Step 8** (box `a3-40-8`)**.** Gold is 15 of 43, about **35%** of customers. The intended observation: a top
tier holding nearly a third of your customer base is not a top tier — it is a majority
discount, and it costs more than it motivates. A real programme would set the Gold threshold
much higher. Credit any answer that computes the share and reasons about whether it is
defensible.

---

## 3-41 · Knowledge Database (SQLite)

See `solutions-ch3.sql`. Headline figures:

- 24 employees. Offices: Pullman 12 · Moscow 5 · Colfax 5 · Lewiston 2.
- Expertise: British Airways 7 · American Airlines 7 · Delta 5 · Continental 5.
- British Airways experts: Boyd, Choi, Henderson, Nauman, Stewart, Thornton, Walker.

**Step 3 is the exercise's real question, and the answer is an empty result**
(query box `s3-41-3`, written answer `a3-41-3`)**.** Lewiston has
two staff — Proctor (Continental) and Weber (American Airlines) — so nobody there covers
British Airways and the query returns **zero rows**. The export shows that as
`Result 1 · 0 rows` with an empty table — that is the correct output, not a failed run.
The graded work is the written answer: students must recognise that the empty
result *is* the finding, and that the call has to be routed to one of the seven experts elsewhere.
A student who reports "the query didn't work" has missed the point of the whole exercise;
a student who then writes the follow-up query listing all BA experts by office has exceeded
it. (The step's chips deliberately carry no row count, so the count is not handed to them.)

**Step 4 (coverage gaps, box `s3-41-4`).** 4 offices × 4 airlines = 16 possible pairs, 12 exist, **4 are
missing**:

| Office | Uncovered airline |
|---|---|
| Colfax | Continental |
| Lewiston | British Airways |
| Lewiston | Delta |
| Moscow | American Airlines |

This is the hardest query in the set. Partial credit generously — a student who produces the
`CROSS JOIN` of offices and expertise without the `LEFT JOIN ... IS NULL` filter has done the
conceptually hard half.

**Step 5** (query box `s3-41-5`, written answer `a3-41-5`)**.** `ALTER TABLE employees ADD COLUMN employee_id INTEGER;` adds the column but
SQLite will not add a `PRIMARY KEY` constraint through `ALTER TABLE`. Both the simple version
and the full table rebuild earn credit; a student who *notices and states* the limitation has
understood more than one who does not. On the page, running the box twice fails with
`duplicate column name: employee_id` (the box's error message names it); Reset database restores the
original 24-row `employees.db` without the column, so the submitted `.db` and the export's "Database at export
time" `CREATE TABLE` are where the change shows.

**Step 6** (box `a3-41-6`)**.** Discussion. Look for two of: expertise is one value per person with no room for a
second airline or a proficiency level; nothing records who verified the expertise or when;
nothing expires; the database points at people rather than storing knowledge, so it fails
when someone leaves; only home phone numbers are held, which is a privacy problem. The
strongest answers connect this to step 4 — the schema cannot express "partly covered".

---

## Grading notes across all six

**The formula line is where marks are actually lost.** Correct numbers typed in by hand look
identical to correct numbers computed. Spot-check by clicking a summary cell in each
submission and confirming the formula bar is not showing a literal.

**The written answers are 20 points each and are routinely skipped or padded.** Every
discussion question here has a defensible answer grounded in the student's own output; a
response that restates the number without interpreting it earns none of the 20.

**On zip files.** Students frequently submit the `.csv` rather than the `.xlsx`, losing every
formula. Consider a one-time regrade window for that specific mistake the first week, then
enforce it.

**Reading the export.** A query whose box shows `_(written but never run — press Run before exporting)_` or
`_(this result is from an earlier version of the box — press Run again to refresh it)_` has no trustworthy
result: grade the SQL text, and if it matters, paste it into the submitted `.db` yourself. A result table in the
export is capped at 200 rows ("… n more rows"), which never affects these exercises (the largest result is 43
rows). The Terminal transcript is complete — for chapter 1 it should show two imports, the second with
`zip TEXT` and `frequent_flier_number TEXT`.
